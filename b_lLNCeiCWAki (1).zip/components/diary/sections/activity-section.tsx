"use client"

import { useState } from "react"
import { SectionCard } from "../section-card"
import { DraggableRow, AddButton } from "../draggable-row"
import { InputField, SelectField } from "../input-field"

interface ActivityItem {
  id: string
  date: string
  name: string
  category: string
  type: string
  customType?: string
  companion: string
}

interface ActivitySectionProps {
  items: ActivityItem[]
  onItemsChange: (items: ActivityItem[]) => void
}

// 유형 옵션 (활동과 회합의 하위 항목만 선택 가능)
const typeOptions = [
  { value: "", label: "유형", disabled: true },
  { value: "활동-header", label: "── 활동 ──", disabled: true },
  { value: "대화", label: "대화" },
  { value: "연락", label: "연락" },
  { value: "칸나", label: "칸나" },
  { value: "회합-header", label: "── 회합 ──", disabled: true },
  { value: "좌담회", label: "좌담회" },
  { value: "창제회", label: "창제회" },
  { value: "협의", label: "협의" },
  { value: "직접입력", label: "직접입력" },
]

// 유형에서 카테고리 추출
const getCategory = (type: string): string => {
  if (["대화", "연락", "칸나"].includes(type)) return "활동"
  if (["좌담회", "창제회", "협의"].includes(type)) return "회합"
  if (type === "직접입력") return "직접입력"
  return ""
}

// 소형 유틸 버튼
function SmallButton({ onClick, children }: { onClick: () => void; children: React.ReactNode }) {
  return (
    <button
      onClick={onClick}
      className="h-[26px] rounded-[var(--r-sm)] border-[1.5px] border-app-border bg-surface px-2.5 text-[11px] font-semibold text-text2"
    >
      {children}
    </button>
  )
}

// 날짜 입력 컴포넌트 (캘린더 팝업)
function DateInput({ value, onChange }: { value: string; onChange: (v: string) => void }) {
  const [showPicker, setShowPicker] = useState(false)
  
  const formatDisplay = (dateStr: string) => {
    if (!dateStr) return ""
    const date = new Date(dateStr)
    return `${date.getMonth() + 1}/${date.getDate()}`
  }

  return (
    <div className="relative">
      <button
        type="button"
        onClick={() => setShowPicker(!showPicker)}
        className="h-[34px] w-[52px] rounded-[var(--r-sm)] border-[1.5px] border-app-border bg-bg px-2 text-center text-[12px] text-text focus:border-green focus:outline-none"
      >
        {formatDisplay(value) || "날짜"}
      </button>
      {showPicker && (
        <>
          <div className="fixed inset-0 z-40" onClick={() => setShowPicker(false)} />
          <div className="absolute left-0 top-full z-50 mt-1 rounded-lg border border-app-border bg-surface p-2 shadow-lg">
            <input
              type="date"
              value={value}
              onChange={(e) => {
                onChange(e.target.value)
                setShowPicker(false)
              }}
              className="rounded-[var(--r-sm)] border border-app-border bg-bg px-2 py-1 text-[12px] text-text"
            />
          </div>
        </>
      )}
    </div>
  )
}

export function ActivitySection({ items, onItemsChange }: ActivitySectionProps) {
  const handleAdd = () => {
    onItemsChange([
      ...items,
      { id: crypto.randomUUID(), date: "", name: "", category: "", type: "", customType: "", companion: "" },
    ])
  }

  const handleDelete = (id: string) => {
    onItemsChange(items.filter((item) => item.id !== id))
  }

  const handleUpdate = (id: string, field: keyof ActivityItem, value: string) => {
    onItemsChange(
      items.map((item) => {
        if (item.id !== id) return item
        
        // 유형 변경시 카테고리도 자동 업데이트
        if (field === "type") {
          const category = getCategory(value)
          return { ...item, type: value, category, customType: value === "직접입력" ? item.customType : "" }
        }
        
        return { ...item, [field]: value }
      })
    )
  }

  const handleLoad = () => {
    console.log("불러오기")
  }

  const handleCopy = () => {
    console.log("복사")
  }

  return (
    <SectionCard
      title="활동 일정"
      color="green"
      headerRight={
        <div className="flex gap-1.5">
          <SmallButton onClick={handleLoad}>불러오기</SmallButton>
          <SmallButton onClick={handleCopy}>복사</SmallButton>
        </div>
      }
    >
      <div className="flex flex-col gap-2">
        {items.map((item) => (
          <DraggableRow key={item.id} onDelete={() => handleDelete(item.id)}>
            <DateInput
              value={item.date}
              onChange={(v) => handleUpdate(item.id, "date", v)}
            />
            <InputField
              value={item.name}
              onChange={(v) => handleUpdate(item.id, "name", v)}
              placeholder="이름"
              width="44px"
            />
            <SelectField
              value={item.type}
              onChange={(v) => handleUpdate(item.id, "type", v)}
              options={typeOptions}
              placeholder="유형"
              width="72px"
            />
            {item.type === "직접입력" && (
              <InputField
                value={item.customType || ""}
                onChange={(v) => handleUpdate(item.id, "customType", v)}
                placeholder="입력"
                width="64px"
              />
            )}
            <InputField
              value={item.companion}
              onChange={(v) => handleUpdate(item.id, "companion", v)}
              placeholder="동행"
              width="48px"
            />
          </DraggableRow>
        ))}
        <div className="ml-0">
          <AddButton onClick={handleAdd} />
        </div>
      </div>
    </SectionCard>
  )
}
