"use client"

import { SectionCard } from "../section-card"
import { TextareaField } from "../input-field"

interface SpeechSectionProps {
  value: string
  onChange: (value: string) => void
}

export function SpeechSection({ value, onChange }: SpeechSectionProps) {
  return (
    <SectionCard title="한 줄 스피치" color="purple">
      <TextareaField
        value={value}
        onChange={onChange}
        placeholder="오늘의 스피치를 기록해주세요..."
        minHeight={60}
      />
    </SectionCard>
  )
}

// 결의 섹션 (분리됨)
interface ResolutionSectionProps {
  value: string
  onChange: (value: string) => void
}

export function ResolutionSection({ value, onChange }: ResolutionSectionProps) {
  return (
    <SectionCard title="결의" color="purple">
      <TextareaField
        value={value}
        onChange={onChange}
        placeholder="오늘의 결의를 기록해주세요..."
        minHeight={60}
      />
    </SectionCard>
  )
}
