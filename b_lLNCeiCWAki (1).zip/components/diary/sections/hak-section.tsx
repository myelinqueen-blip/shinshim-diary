"use client"

import { SectionCard } from "../section-card"
import { DraggableRow, AddButton } from "../draggable-row"
import { InputField, SelectField } from "../input-field"

interface HakItem {
  id: string
  bookType: string
  bookName: string
  startPage: string
  endPage: string
}

interface HakSectionProps {
  items: HakItem[]
  onItemsChange: (items: HakItem[]) => void
  goal: number
}

const bookTypeOptions = [
  { value: "도서", label: "도서" },
  { value: "어서", label: "어서" },
]

export function HakSection({ items, onItemsChange, goal }: HakSectionProps) {
  const handleAdd = () => {
    // 기본값으로 '도서' 선택
    onItemsChange([
      ...items,
      { id: crypto.randomUUID(), bookType: "도서", bookName: "", startPage: "", endPage: "" },
    ])
  }

  const handleDelete = (id: string) => {
    onItemsChange(items.filter((item) => item.id !== id))
  }

  const handleUpdate = (id: string, field: keyof HakItem, value: string) => {
    onItemsChange(
      items.map((item) =>
        item.id === id ? { ...item, [field]: value } : item
      )
    )
  }

  // 각 항목별 페이지 수 계산
  const getItemPages = (item: HakItem) => {
    const start = parseInt(item.startPage) || 0
    const end = parseInt(item.endPage) || 0
    return Math.max(0, end - start + 1)
  }

  const totalPages = items.reduce((sum, item) => sum + getItemPages(item), 0)

  return (
    <SectionCard title="학 · 연찬" color="blue">
      <div className="flex flex-col gap-2">
        {items.map((item) => {
          const itemPages = getItemPages(item)
          return (
            <div key={item.id} className="flex flex-col gap-1.5">
              <DraggableRow onDelete={() => handleDelete(item.id)}>
                <SelectField
                  value={item.bookType}
                  onChange={(v) => handleUpdate(item.id, "bookType", v)}
                  options={bookTypeOptions}
                  placeholder="분류"
                  width="56px"
                />
                <InputField
                  value={item.bookName}
                  onChange={(v) => handleUpdate(item.id, "bookName", v)}
                  placeholder="도서명/어서명"
                  className="flex-1"
                />
              </DraggableRow>
              {/* 페이지 입력 + 총 페이지 표시 */}
              <div className="ml-[21px] flex items-center gap-1.5">
                <InputField
                  value={item.startPage}
                  onChange={(v) => handleUpdate(item.id, "startPage", v)}
                  placeholder="p."
                  width="56px"
                  type="number"
                />
                <span className="text-[13px] text-text3">~</span>
                <InputField
                  value={item.endPage}
                  onChange={(v) => handleUpdate(item.id, "endPage", v)}
                  placeholder="p."
                  width="56px"
                  type="number"
                />
                {itemPages > 0 && (
                  <span className="ml-1 text-[12px] font-semibold text-blue">
                    {itemPages}p
                  </span>
                )}
              </div>
            </div>
          )
        })}
        <div className="ml-0">
          <AddButton onClick={handleAdd} />
        </div>
      </div>
      

    </SectionCard>
  )
}
