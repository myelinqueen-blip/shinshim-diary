"use client"

import { SectionCard } from "../section-card"
import { DraggableRow, AddButton } from "../draggable-row"
import { InputField } from "../input-field"

interface MemberItem {
  id: string
  name: string
  memo: string
}

interface MemberSectionProps {
  items: MemberItem[]
  onItemsChange: (items: MemberItem[]) => void
}

export function MemberSection({ items, onItemsChange }: MemberSectionProps) {
  const handleAdd = () => {
    onItemsChange([
      ...items,
      { id: crypto.randomUUID(), name: "", memo: "" },
    ])
  }

  const handleDelete = (id: string) => {
    onItemsChange(items.filter((item) => item.id !== id))
  }

  const handleUpdate = (id: string, field: keyof MemberItem, value: string) => {
    onItemsChange(
      items.map((item) =>
        item.id === id ? { ...item, [field]: value } : item
      )
    )
  }

  return (
    <SectionCard title="멤버 상황" color="teal">
      <div className="flex flex-col gap-2">
        {items.map((item) => (
          <DraggableRow key={item.id} onDelete={() => handleDelete(item.id)}>
            <InputField
              value={item.name}
              onChange={(v) => handleUpdate(item.id, "name", v)}
              placeholder="이름"
              width="90px"
            />
            <InputField
              value={item.memo}
              onChange={(v) => handleUpdate(item.id, "memo", v)}
              placeholder="상황 메모"
              className="flex-1"
            />
          </DraggableRow>
        ))}
        {/* +추가 버튼 왼쪽 정렬 */}
        <div className="ml-0">
          <AddButton onClick={handleAdd} />
        </div>
      </div>
    </SectionCard>
  )
}
