"use client"

import { SectionCard } from "../section-card"
import { DraggableRow, AddButton } from "../draggable-row"
import { InputField, SelectField } from "../input-field"

interface HaengItem {
  id: string
  name: string
  type: string
  category: string
  customType?: string
}

interface HaengSectionProps {
  items: HaengItem[]
  onItemsChange: (items: HaengItem[]) => void
  goal: number
}

// 유형 옵션 (활동과 회합의 하위 항목만 선택 가능)
const typeOptions = [
  { value: "", label: "유형", disabled: true },
  { value: "활동-header", label: "── 활동 ──", disabled: true },
  { value: "대화", label: "대화" },
  { value: "연락", label: "연락" },
  { value: "칸나", label: "칸나" },
  { value: "회합-header", label: "── 회합 ──", disabled: true },
  { value: "좌담회", label: "좌담회" },
  { value: "창제회", label: "창제회" },
  { value: "협의", label: "협의" },
  { value: "직접입력", label: "직접입력" },
]

// 유형에서 카테고리 추출
const getCategory = (type: string): string => {
  if (["대화", "연락", "칸나"].includes(type)) return "활동"
  if (["좌담회", "창제회", "협의"].includes(type)) return "회합"
  if (type === "직접입력") return "직접입력"
  return ""
}

export function HaengSection({ items, onItemsChange, goal }: HaengSectionProps) {
  const handleAdd = () => {
    onItemsChange([
      ...items,
      { id: crypto.randomUUID(), name: "", type: "", category: "", customType: "" },
    ])
  }

  const handleDelete = (id: string) => {
    onItemsChange(items.filter((item) => item.id !== id))
  }

  const handleUpdate = (id: string, field: keyof HaengItem, value: string) => {
    onItemsChange(
      items.map((item) => {
        if (item.id !== id) return item
        
        // 유형 변경시 카테고리도 자동 업데이트
        if (field === "type") {
          const category = getCategory(value)
          return { ...item, type: value, category, customType: value === "직접입력" ? item.customType : "" }
        }
        
        return { ...item, [field]: value }
      })
    )
  }

  const completedCount = items.filter((i) => i.name && i.type).length

  return (
    <SectionCard title="행 · 활동" color="pink">
      <div className="flex flex-col gap-2">
        {items.map((item) => (
          <DraggableRow key={item.id} onDelete={() => handleDelete(item.id)}>
            <InputField
              value={item.name}
              onChange={(v) => handleUpdate(item.id, "name", v)}
              placeholder="이름"
              className="flex-1"
            />
            <SelectField
              value={item.type}
              onChange={(v) => handleUpdate(item.id, "type", v)}
              options={typeOptions}
              placeholder="유형"
              width="80px"
            />
            {item.type === "직접입력" && (
              <InputField
                value={item.customType || ""}
                onChange={(v) => handleUpdate(item.id, "customType", v)}
                placeholder="입력"
                width="72px"
              />
            )}
          </DraggableRow>
        ))}
        <div className="ml-0">
          <AddButton onClick={handleAdd} />
        </div>
      </div>
    </SectionCard>
  )
}
