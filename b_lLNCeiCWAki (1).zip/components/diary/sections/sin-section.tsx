"use client"

import { SectionCard } from "../section-card"
import { ProgressBar } from "../progress-bar"
import { NumberInput } from "../input-field"

interface SinSectionProps {
  minutes: string
  onMinutesChange: (value: string) => void
  goal: number
}

function formatTime(minutes: number): string {
  const h = Math.floor(minutes / 60)
  const m = minutes % 60
  if (h === 0) return `${m}m`
  return m === 0 ? `${h}h` : `${h}h ${m}m`
}

export function SinSection({ minutes, onMinutesChange, goal }: SinSectionProps) {
  const numMinutes = parseInt(minutes) || 0
  
  return (
    <SectionCard title="신 · 창제" color="green">
      <div className="flex items-center gap-3">
        <NumberInput
          value={minutes}
          onChange={onMinutesChange}
          placeholder="0"
        />
        <span className="text-[13px] text-text">분</span>
        <span className="text-[13px] text-text2">→</span>
        <span className="text-[26px] font-black text-green">
          {formatTime(numMinutes)}
        </span>
      </div>
      
      <div className="mt-3">
        <ProgressBar
          value={numMinutes}
          max={goal}
          color="green"
          leftLabel="0분"
          rightLabel={`${Math.round((numMinutes / goal) * 100)}%`}
        />
      </div>
    </SectionCard>
  )
}
