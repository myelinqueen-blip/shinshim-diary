"use client"

import { ChevronLeft, ChevronRight } from "lucide-react"

const dayNames = ["일", "월", "화", "수", "목", "금", "토"]

interface DateNavigationProps {
  date: Date
  onDateChange: (date: Date) => void
  onToday: () => void
}

export function DateNavigation({ date, onDateChange, onToday }: DateNavigationProps) {
  const year = date.getFullYear()
  const month = date.getMonth() + 1
  const day = date.getDate()
  const dayName = dayNames[date.getDay()]

  const handlePrev = () => {
    const newDate = new Date(date)
    newDate.setDate(newDate.getDate() - 1)
    onDateChange(newDate)
  }

  const handleNext = () => {
    const newDate = new Date(date)
    newDate.setDate(newDate.getDate() + 1)
    onDateChange(newDate)
  }

  return (
    <div className="sticky top-[44px] z-50 flex h-[54px] items-center gap-2 border-b border-app-border bg-surface px-3">
      {/* 이전 버튼 */}
      <button
        onClick={handlePrev}
        className="flex h-[40px] w-[40px] items-center justify-center rounded-[10px] border-[1.5px] border-app-border bg-surface"
      >
        <ChevronLeft className="h-5 w-5 text-text2" />
      </button>

      {/* 날짜 표시 */}
      <div className="flex flex-1 max-w-[150px] flex-col items-center justify-center">
        <span className="text-[10px] text-text3">{year}</span>
        <span className="text-[18px] font-black text-text">
          {month}월 {day}일 ({dayName})
        </span>
      </div>

      {/* 다음 버튼 */}
      <button
        onClick={handleNext}
        className="flex h-[40px] w-[40px] items-center justify-center rounded-[10px] border-[1.5px] border-app-border bg-surface"
      >
        <ChevronRight className="h-5 w-5 text-text2" />
      </button>

      {/* 오늘 버튼 */}
      <button
        onClick={onToday}
        className="ml-auto h-[36px] rounded-[var(--r-sm)] bg-green px-4 text-[12px] font-bold text-white"
      >
        오늘
      </button>
    </div>
  )
}
