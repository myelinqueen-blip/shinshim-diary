"use client"

import { cn } from "@/lib/utils"
import { ChevronDown } from "lucide-react"

interface InputFieldProps {
  value: string
  onChange: (value: string) => void
  placeholder?: string
  className?: string
  type?: "text" | "number"
  width?: string
}

export function InputField({
  value,
  onChange,
  placeholder,
  className,
  type = "text",
  width,
}: InputFieldProps) {
  return (
    <input
      type={type}
      value={value}
      onChange={(e) => onChange(e.target.value)}
      placeholder={placeholder}
      className={cn(
        "h-[34px] rounded-[var(--r-sm)] border-[1.5px] border-app-border bg-bg px-2.5 text-[13px] text-text placeholder:text-text3",
        "focus:border-green focus:outline-none",
        className
      )}
      style={{ width }}
    />
  )
}

// 숫자 입력 (신/창제용 큰 입력)
export function NumberInput({
  value,
  onChange,
  placeholder,
  className,
}: {
  value: string
  onChange: (value: string) => void
  placeholder?: string
  className?: string
}) {
  return (
    <input
      type="number"
      inputMode="numeric"
      value={value}
      onChange={(e) => onChange(e.target.value)}
      placeholder={placeholder}
      className={cn(
        "h-[46px] w-[90px] rounded-[var(--r-sm)] border-[1.5px] border-app-border bg-bg text-center text-[22px] font-black text-text placeholder:text-text3",
        "focus:border-green focus:outline-none",
        className
      )}
    />
  )
}

// 셀렉트 드롭다운
interface SelectFieldProps {
  value: string
  onChange: (value: string) => void
  options: { value: string; label: string; disabled?: boolean }[]
  placeholder?: string
  className?: string
  width?: string
}

export function SelectField({
  value,
  onChange,
  options,
  placeholder,
  className,
  width,
}: SelectFieldProps) {
  return (
    <div className="relative" style={{ width }}>
      <select
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className={cn(
          "h-[34px] w-full appearance-none rounded-[var(--r-sm)] border-[1.5px] border-app-border bg-bg pl-2.5 pr-7 text-[13px] text-text",
          "focus:border-green focus:outline-none",
          !value && "text-text3",
          className
        )}
      >
        {placeholder && (
          <option value="" disabled>
            {placeholder}
          </option>
        )}
        {options.map((opt) => (
          <option key={opt.value} value={opt.value} disabled={opt.disabled}>
            {opt.label}
          </option>
        ))}
      </select>
      <ChevronDown className="pointer-events-none absolute right-2 top-1/2 h-4 w-4 -translate-y-1/2 text-text3" />
    </div>
  )
}

// 텍스트에어리어
export function TextareaField({
  value,
  onChange,
  placeholder,
  className,
  minHeight = 60,
}: {
  value: string
  onChange: (value: string) => void
  placeholder?: string
  className?: string
  minHeight?: number
}) {
  return (
    <textarea
      value={value}
      onChange={(e) => onChange(e.target.value)}
      placeholder={placeholder}
      className={cn(
        "w-full resize-none rounded-[var(--r-sm)] border-[1.5px] border-app-border bg-bg p-2.5 text-[13px] text-text placeholder:text-text3",
        "focus:border-green focus:outline-none",
        className
      )}
      style={{ minHeight }}
    />
  )
}
