"use client"

import { useState } from "react"
import { Search, ChevronLeft, ChevronRight, Copy, Check, Edit2, X, ChevronDown } from "lucide-react"
import { cn } from "@/lib/utils"
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  ReferenceLine,
} from "recharts"

const filterPills = [
  { id: "all", label: "전체", color: "green" },
  { id: "sin", label: "창제", color: "green" },
  { id: "haeng", label: "활동", color: "pink" },
  { id: "hak", label: "연찬", color: "blue" },
  { id: "speech", label: "스피치", color: "purple" },
  { id: "resolution", label: "결의", color: "teal" },
  { id: "member", label: "멤버", color: "teal" },
] as const

type FilterId = (typeof filterPills)[number]["id"]

const colorStyles: Record<string, { active: string; inactive: string }> = {
  green: { active: "bg-green text-white", inactive: "bg-green-l text-green" },
  pink: { active: "bg-pink text-white", inactive: "bg-pink-l text-pink" },
  blue: { active: "bg-blue text-white", inactive: "bg-blue-l text-blue" },
  purple: { active: "bg-purple text-white", inactive: "bg-purple-l text-purple" },
  teal: { active: "bg-teal text-white", inactive: "bg-teal-l text-teal" },
}

// 기본 보고문구
const defaultReportText = `<서울8방면 신강북권 총합권여자부장 오선민>



안녕하세요! 신행학 보고드립니다!

`

// 더미 데이터
const dummyRecords = [
  {
    date: "2026-04-02",
    sinMinutes: 90,
    haeng: [
      { name: "승리지부 창제회", category: "회합", type: "창제회" },
      { name: "고경자 미양지부 총합여성부장님 통화", category: "활동", type: "연락" },
    ],
    hak: [
      { bookType: "도서", bookName: "신인간혁명 3권", startPage: "291", endPage: "337" },
      { bookType: "정기간행물", bookName: "법련 4월호", startPage: "1", endPage: "65" },
    ],
    resolution: "오늘도 전진합니다!",
    speech: "신인간혁명 3권 291페이지부터 337페이지까지 공부하며 선생님의 제자로서 더욱 성장하겠다고 다짐했습니다.",
    members: [
      { name: "황지윤", branch: "수유지부B", memo: "일대일 근행회를 진행했고 저와 매달 만나 근행하기로 했습니다." },
    ],
  },
  {
    date: "2026-04-04",
    sinMinutes: 60,
    haeng: [
      { name: "최민수", category: "활동", type: "연락" },
      { name: "정수연", category: "활동", type: "칸나" },
      { name: "강동원", category: "회합", type: "창제회" },
    ],
    hak: [
      { bookType: "어서", bookName: "봄을 여는 사자후", startPage: "1", endPage: "11" },
    ],
    resolution: "모든 만남에 진심을 다하겠습니다.",
    speech: "",
    members: [
      { name: "송현아", branch: "", memo: "취업 준비 중" },
      { name: "윤서준", branch: "", memo: "신입 환영" },
    ],
  },
  {
    date: "2026-04-03",
    sinMinutes: 30,
    haeng: [
      { name: "임지훈", category: "활동", type: "대화" },
    ],
    hak: [
      { bookType: "도서", bookName: "청춘대화", startPage: "45", endPage: "60" },
    ],
    resolution: "포기하지 않는 도전을 계속하겠습니다.",
    speech: "청춘대화를 통해 나 자신의 가능성을 믿는 것이 얼마나 중요한지 깨달았습니다.",
    members: [],
  },
  {
    date: "2026-04-01",
    sinMinutes: 120,
    haeng: [
      { name: "박지민", category: "활동", type: "대화" },
      { name: "이수진", category: "활동", type: "대화" },
    ],
    hak: [
      { bookType: "도서", bookName: "인간혁명", startPage: "1", endPage: "50" },
    ],
    resolution: "새 달의 시작! 힘차게 전진!",
    speech: "",
    members: [
      { name: "황지윤", branch: "수유지부B", memo: "이번 달 목표 설정 완료" },
    ],
  },
  {
    date: "2026-04-05",
    sinMinutes: 45,
    haeng: [
      { name: "김영희", category: "활동", type: "칸나" },
    ],
    hak: [],
    resolution: "",
    speech: "오늘 하루도 감사한 마음으로 보냈습니다.",
    members: [
      { name: "송현아", branch: "", memo: "면접 결과 기다리는 중" },
    ],
  },
]

// 활동 유형별 카운트 계산
function getActivityCounts() {
  const counts: Record<string, number> = {}
  dummyRecords.forEach(record => {
    record.haeng.forEach(h => {
      counts[h.type] = (counts[h.type] || 0) + 1
    })
  })
  return counts
}

// 멤버별 기록 그룹핑
function getMemberRecords() {
  const memberMap: Record<string, { date: string; memo: string; branch: string }[]> = {}
  
  dummyRecords.forEach(record => {
    record.members.forEach(m => {
      if (!memberMap[m.name]) {
        memberMap[m.name] = []
      }
      memberMap[m.name].push({
        date: record.date,
        memo: m.memo,
        branch: m.branch,
      })
    })
  })
  
  // 각 멤버의 기록을 최신순으로 정렬
  Object.keys(memberMap).forEach(name => {
    memberMap[name].sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
  })
  
  return memberMap
}

// 일일 창제 시간 데이터
function getDailyChantingData() {
  return dummyRecords
    .map(r => ({
      date: r.date,
      minutes: r.sinMinutes,
      label: `${new Date(r.date).getMonth() + 1}/${new Date(r.date).getDate()}`,
    }))
    .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime())
}

// 목표 일일 평균 계산 (예: 30일 기간에 50시간 목표)
const goalTotalMinutes = 3000 // 50시간
const periodDays = 30
const dailyGoalMinutes = Math.round(goalTotalMinutes / periodDays)

// 복사 버튼 컴포넌트
function CopyButton({ text }: { text: string }) {
  const [copied, setCopied] = useState(false)

  const handleCopy = async () => {
    await navigator.clipboard.writeText(text)
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  return (
    <button
      onClick={handleCopy}
      className="flex h-6 w-6 shrink-0 items-center justify-center rounded border border-app-border bg-surface text-text3 hover:border-green hover:text-green transition-colors"
    >
      {copied ? <Check className="h-3 w-3" /> : <Copy className="h-3 w-3" />}
    </button>
  )
}

// 보고문구 편집 모달
function ReportEditModal({
  isOpen,
  onClose,
  reportText,
  onSave
}: {
  isOpen: boolean
  onClose: () => void
  reportText: string
  onSave: (text: string) => void
}) {
  const [editText, setEditText] = useState(reportText)

  if (!isOpen) return null

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4">
      <div className="w-full max-w-[360px] rounded-[var(--r)] bg-surface p-5">
        <div className="mb-4 flex items-center justify-between">
          <h2 className="text-[16px] font-extrabold text-text">보고문구 편집</h2>
          <button onClick={onClose} className="text-text3 hover:text-text">
            <X className="h-5 w-5" />
          </button>
        </div>
        
        <textarea
          value={editText}
          onChange={(e) => setEditText(e.target.value)}
          placeholder="보고문구를 입력하세요..."
          rows={8}
          className="mb-4 w-full resize-none rounded-[var(--r-sm)] border-[1.5px] border-app-border bg-bg p-3 text-[13px] text-text placeholder:text-text3 focus:border-green focus:outline-none"
        />

        <div className="flex gap-3">
          <button
            onClick={onClose}
            className="flex-1 rounded-[var(--r-sm)] border-[1.5px] border-app-border bg-surface py-2.5 text-[13px] font-bold text-text2"
          >
            취소
          </button>
          <button
            onClick={() => { onSave(editText); onClose() }}
            className="flex-1 rounded-[var(--r-sm)] bg-green py-2.5 text-[13px] font-bold text-white"
          >
            저장
          </button>
        </div>
      </div>
    </div>
  )
}

// 창제 섹션 - 막대 그래프 + 일자별 리스트
function SinSection() {
  const chartData = getDailyChantingData()
  const maxMinutes = Math.max(...chartData.map(d => d.minutes), dailyGoalMinutes)
  
  return (
    <div className="flex flex-col gap-3">
      {/* 일일 창제 시간 막대 그래프 */}
      <div className="rounded-[var(--r)] border border-app-border bg-surface p-4">
        <h3 className="mb-3 text-[14px] font-bold text-text">일일 창제 시간</h3>
        <div className="flex flex-col gap-2">
          {chartData.map((item, idx) => {
            const barWidth = Math.max((item.minutes / maxMinutes) * 100, 5)
            const isAboveGoal = item.minutes >= dailyGoalMinutes
            
            return (
              <div key={idx} className="flex items-center gap-2">
                <span className="w-[40px] shrink-0 text-[11px] text-text3">{item.label}</span>
                <div className="flex-1 h-[24px] rounded-full bg-gray-100 overflow-hidden relative">
                  <div
                    className={cn(
                      "h-full rounded-full transition-all duration-300",
                      isAboveGoal ? "bg-green" : "bg-green/60"
                    )}
                    style={{ width: `${barWidth}%` }}
                  />
                  {/* 목표선 */}
                  <div 
                    className="absolute top-0 bottom-0 w-0.5 bg-pink"
                    style={{ left: `${(dailyGoalMinutes / maxMinutes) * 100}%` }}
                  />
                </div>
                <span className={cn(
                  "w-[45px] shrink-0 text-right text-[12px] font-bold",
                  isAboveGoal ? "text-green" : "text-text2"
                )}>{item.minutes}분</span>
              </div>
            )
          })}
        </div>
        <div className="mt-3 flex items-center justify-between text-[10px] text-text3">
          <span>목표: {Math.floor(goalTotalMinutes / 60)}시간 / {periodDays}일</span>
          <div className="flex items-center gap-1">
            <div className="h-0.5 w-3 bg-pink" />
            <span>일일 목표 {dailyGoalMinutes}분</span>
          </div>
        </div>
      </div>
      
      {/* 일자별 창제 시간 리스트 */}
      <div className="rounded-[var(--r)] border border-app-border bg-surface p-4">
        <h3 className="mb-3 text-[14px] font-bold text-text">일자별 기록</h3>
        <div className="flex flex-col gap-2">
          {chartData.map((item, idx) => (
            <div key={idx} className="flex items-center justify-between rounded-lg bg-green-l/50 px-3 py-2">
              <span className="text-[12px] text-text2">{item.label}</span>
              <span className="text-[13px] font-bold text-green">{item.minutes}분</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}

// 활동 유형별 상세 데이터 가져오기
function getActivityDetails() {
  const details: Record<string, { date: string; name: string; category: string }[]> = {}
  
  dummyRecords.forEach(record => {
    record.haeng.forEach(h => {
      if (!details[h.type]) {
        details[h.type] = []
      }
      details[h.type].push({
        date: record.date,
        name: h.name,
        category: h.category,
      })
    })
  })
  
  // 각 유형별로 날짜순 정렬
  Object.keys(details).forEach(type => {
    details[type].sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
  })
  
  return details
}

// 활동 섹션 - 바 차트 + 클릭시 상세 정보
function HaengSection() {
  const activityCounts = getActivityCounts()
  const activityDetails = getActivityDetails()
  const [selectedType, setSelectedType] = useState<string | null>(null)
  
  const sortedRecords = [...dummyRecords].sort((a, b) => 
    new Date(b.date).getTime() - new Date(a.date).getTime()
  )
  
  // 바 차트에 사용할 최대값 계산
  const maxCount = Math.max(...Object.values(activityCounts), 1)
  
  // 유형별 색상
  const typeColors: Record<string, { bar: string; bg: string; text: string }> = {
    "대화": { bar: "bg-pink", bg: "bg-pink-l", text: "text-pink" },
    "연락": { bar: "bg-purple", bg: "bg-purple-l", text: "text-purple" },
    "칸나": { bar: "bg-teal", bg: "bg-teal-l", text: "text-teal" },
    "좌담회": { bar: "bg-blue", bg: "bg-blue-l", text: "text-blue" },
    "창제회": { bar: "bg-green", bg: "bg-green-l", text: "text-green" },
    "협의": { bar: "bg-indigo", bg: "bg-indigo-l", text: "text-indigo" },
  }
  
  const getColors = (type: string) => typeColors[type] || { bar: "bg-pink", bg: "bg-pink-l", text: "text-pink" }
  
  const formatDate = (dateStr: string) => {
    const date = new Date(dateStr)
    const days = ["일", "월", "화", "수", "목", "금", "토"]
    return `${date.getMonth() + 1}/${date.getDate()}(${days[date.getDay()]})`
  }
  
  const handleBarClick = (type: string) => {
    setSelectedType(selectedType === type ? null : type)
  }
  
  return (
    <div className="flex flex-col gap-3">
      {/* 활동 현황 바 차트 */}
      <div className="rounded-[var(--r)] border border-app-border bg-surface p-4">
        <h3 className="mb-4 text-[14px] font-bold text-text">활동 현황</h3>
        
        {/* 바 차트 */}
        <div className="flex flex-col gap-3">
          {Object.entries(activityCounts).map(([type, count]) => {
            const colors = getColors(type)
            const isSelected = selectedType === type
            const barWidth = Math.max((count / maxCount) * 100, 10) // 최소 10%
            
            return (
              <div key={type}>
                <button
                  onClick={() => handleBarClick(type)}
                  className={cn(
                    "w-full rounded-lg p-2 transition-all",
                    isSelected ? colors.bg : "hover:bg-gray-50"
                  )}
                >
                  <div className="flex items-center justify-between mb-1.5">
                    <span className={cn("text-[12px] font-semibold", colors.text)}>{type}</span>
                    <span className={cn("text-[12px] font-bold", colors.text)}>{count}회</span>
                  </div>
                  <div className="h-[20px] w-full rounded-full bg-gray-100 overflow-hidden">
                    <div
                      className={cn("h-full rounded-full transition-all duration-300", colors.bar)}
                      style={{ width: `${barWidth}%` }}
                    />
                  </div>
                </button>
                
                {/* 선택된 유형의 상세 정보 */}
                {isSelected && activityDetails[type] && (
                  <div className={cn("mt-2 ml-2 rounded-lg border p-3", colors.bg, "border-transparent")}>
                    <div className="flex flex-col gap-2">
                      {activityDetails[type].map((item, idx) => (
                        <div key={idx} className="flex items-center gap-3">
                          <span className="shrink-0 text-[11px] font-medium text-text3 w-[60px]">
                            {formatDate(item.date)}
                          </span>
                          <span className={cn("text-[12px] font-semibold", colors.text)}>
                            {item.name}
                          </span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            )
          })}
        </div>
        
        {/* 총 활동 횟수 */}
        <div className="mt-4 pt-3 border-t border-app-border flex items-center justify-between">
          <span className="text-[12px] text-text2">총 활동</span>
          <span className="text-[14px] font-bold text-pink">
            {Object.values(activityCounts).reduce((a, b) => a + b, 0)}회
          </span>
        </div>
      </div>
      
      {/* 일자별 활동 리스트 */}
      <div className="flex flex-col gap-2">
        {sortedRecords.filter(r => r.haeng.length > 0).map((record, idx) => {
          const date = new Date(record.date)
          const days = ["일", "월", "화", "수", "목", "금", "토"]
          const dateStr = `${date.getMonth() + 1}/${date.getDate()} (${days[date.getDay()]})`
          
          return (
            <div key={idx} className="flex items-start gap-3 rounded-lg border border-app-border bg-surface p-3">
              <span className="shrink-0 text-[11px] font-semibold text-text3">{dateStr}</span>
              <div className="flex flex-wrap gap-1.5">
                {record.haeng.map((h, i) => {
                  const colors = getColors(h.type)
                  return (
                    <span key={i} className={cn("rounded-full px-2 py-0.5 text-[11px]", colors.bg, colors.text)}>
                      {h.name} ({h.type})
                    </span>
                  )
                })}
              </div>
            </div>
          )
        })}
      </div>
    </div>
  )
}

// 스피치 섹션 - 최신순 정렬
function SpeechSection() {
  const sortedRecords = [...dummyRecords]
    .filter(r => r.speech && r.speech.trim() !== "")
    .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
  
  const formatDate = (dateStr: string) => {
    const date = new Date(dateStr)
    const days = ["일", "월", "화", "수", "목", "금", "토"]
    return `${date.getMonth() + 1}/${date.getDate()} (${days[date.getDay()]})`
  }
  
  return (
    <div className="flex flex-col gap-2">
      {sortedRecords.map((record, idx) => (
        <div key={idx} className="rounded-[var(--r)] border border-app-border bg-surface p-4">
          <div className="mb-2 flex items-center gap-2">
            <span className="rounded bg-purple-l px-1.5 py-0.5 text-[10px] font-semibold text-purple">스피치</span>
            <span className="text-[11px] text-text3">{formatDate(record.date)}</span>
          </div>
          <p className="text-[13px] text-text leading-relaxed">{record.speech}</p>
        </div>
      ))}
      {sortedRecords.length === 0 && (
        <div className="rounded-[var(--r)] border border-app-border bg-surface p-6 text-center">
          <p className="text-[13px] text-text3">스피치 기록이 없습니다</p>
        </div>
      )}
    </div>
  )
}

// 결의 섹션 - 최신순 정렬
function ResolutionSection() {
  const sortedRecords = [...dummyRecords]
    .filter(r => r.resolution && r.resolution.trim() !== "")
    .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
  
  const formatDate = (dateStr: string) => {
    const date = new Date(dateStr)
    const days = ["일", "월", "화", "수", "목", "금", "토"]
    return `${date.getMonth() + 1}/${date.getDate()} (${days[date.getDay()]})`
  }
  
  return (
    <div className="flex flex-col gap-2">
      {sortedRecords.map((record, idx) => (
        <div key={idx} className="rounded-[var(--r)] border border-app-border bg-surface p-4">
          <div className="mb-2 flex items-center gap-2">
            <span className="rounded bg-teal-l px-1.5 py-0.5 text-[10px] font-semibold text-teal">결의</span>
            <span className="text-[11px] text-text3">{formatDate(record.date)}</span>
          </div>
          <p className="text-[13px] text-text font-medium">{record.resolution}</p>
        </div>
      ))}
      {sortedRecords.length === 0 && (
        <div className="rounded-[var(--r)] border border-app-border bg-surface p-6 text-center">
          <p className="text-[13px] text-text3">결의 기록이 없습니다</p>
        </div>
      )}
    </div>
  )
}

// 멤버 섹션 - 접었다 펼쳤다 가능한 리스트
function MemberSection() {
  const memberRecords = getMemberRecords()
  const [expandedMembers, setExpandedMembers] = useState<Record<string, boolean>>({})
  
  const toggleMember = (name: string) => {
    setExpandedMembers(prev => ({ ...prev, [name]: !prev[name] }))
  }
  
  const formatDate = (dateStr: string) => {
    const date = new Date(dateStr)
    const days = ["일", "월", "화", "수", "목", "금", "토"]
    return `${date.getMonth() + 1}/${date.getDate()} (${days[date.getDay()]})`
  }
  
  return (
    <div className="flex flex-col gap-2">
      {Object.entries(memberRecords).map(([name, records]) => {
        const isExpanded = expandedMembers[name]
        const latestBranch = records[0]?.branch
        
        return (
          <div key={name} className="rounded-[var(--r)] border border-app-border bg-surface overflow-hidden">
            {/* 멤버 헤더 (클릭하여 펼침/접힘) */}
            <button
              onClick={() => toggleMember(name)}
              className="flex w-full items-center justify-between p-3 hover:bg-teal-l/30 transition-colors"
            >
              <div className="flex items-center gap-2">
                <span className="text-[14px] font-bold text-text">{name}</span>
                {latestBranch && (
                  <span className="rounded bg-teal-l px-1.5 py-0.5 text-[10px] text-teal">{latestBranch}</span>
                )}
                <span className="text-[11px] text-text3">{records.length}건</span>
              </div>
              <ChevronDown className={cn("h-4 w-4 text-text3 transition-transform", isExpanded && "rotate-180")} />
            </button>
            
            {/* 펼쳐진 내용 */}
            {isExpanded && (
              <div className="border-t border-app-border bg-teal-l/20 px-3 py-2">
                <div className="flex flex-col gap-2">
                  {records.map((record, idx) => (
                    <div key={idx} className="flex items-start gap-2">
                      <span className="shrink-0 text-[11px] font-semibold text-teal">{formatDate(record.date)}</span>
                      <span className="text-[12px] text-text">{record.memo}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        )
      })}
    </div>
  )
}

// 날짜별 전체 기록 카드 (창제, 활동, 연찬, 결의, 멤버 상황만)
function FullRecordCard({ record }: { record: typeof dummyRecords[0] }) {
  const formatDate = (dateStr: string) => {
    const date = new Date(dateStr)
    const days = ["일", "월", "화", "수", "목", "금", "토"]
    return `${date.getMonth() + 1}월 ${date.getDate()}일 (${days[date.getDay()]})`
  }

  const formatDateShort = (dateStr: string) => {
    const date = new Date(dateStr)
    const days = ["일", "월", "화", "수", "목", "금", "토"]
    return `${date.getMonth() + 1}/${date.getDate()}(${days[date.getDay()]})`
  }

  const formatMinutes = (mins: number) => {
    const h = Math.floor(mins / 60)
    const m = mins % 60
    if (h > 0 && m > 0) return `${h}시간 ${m}분`
    if (h > 0) return `${h}시간`
    return `${m}분`
  }

  // 새로운 복사 양식 - 줄간격 공백 삭제
  const buildCopyText = () => {
    let text = `\u2728 ${formatDateShort(record.date)}\n`
    
    // 신 (창제)
    text += `\u25aa\ufe0f신 : ${formatMinutes(record.sinMinutes)}\n`
    
    // 행 (활동)
    if (record.haeng.length > 0) {
      const haengItems = record.haeng.map(h => h.name).join(", ")
      text += `\u25aa\ufe0f행 : ${haengItems}\n`
    } else {
      text += `\u25aa\ufe0f행 : \n`
    }
    
    // 학 (연찬)
    if (record.hak.length > 0) {
      const hakItems = record.hak.map(h => `${h.bookName} (${h.startPage}~${h.endPage}p)`).join(", ")
      text += `\u25aa\ufe0f학 : ${hakItems}\n`
    } else {
      text += `\u25aa\ufe0f학 : \n`
    }
    
    // 결의
    text += `\u25aa\ufe0f결의 : ${record.resolution || ""}\n`
    
    // 멤버 상황
    text += `\u25aa\ufe0f멤버 상황\n`
    if (record.members.length > 0) {
      record.members.forEach((m) => {
        const branchText = m.branch ? ` ${m.branch}` : ""
        text += `   * ${m.name}${branchText} : ${m.memo}\n`
      })
    }
    
    return text
  }

  return (
    <div className="rounded-[var(--r)] border border-app-border bg-surface p-4">
      <div className="mb-3 flex items-center justify-between">
        <span className="text-[14px] font-bold text-text">{formatDate(record.date)}</span>
        <CopyButton text={buildCopyText()} />
      </div>

      <div className="flex flex-col gap-2 text-[12px]">
        {/* 창제 */}
        <div className="flex items-start gap-2">
          <span className="shrink-0 rounded bg-green-l px-1.5 py-0.5 text-[10px] font-semibold text-green">창제</span>
          <span className="text-text">{formatMinutes(record.sinMinutes)}</span>
        </div>

        {/* 활동 */}
        {record.haeng.length > 0 && (
          <div className="flex items-start gap-2">
            <span className="shrink-0 rounded bg-pink-l px-1.5 py-0.5 text-[10px] font-semibold text-pink">활동</span>
            <div className="flex flex-wrap gap-1">
              {record.haeng.map((h, i) => (
                <span key={i} className="text-text">
                  {h.name}({h.type}){i < record.haeng.length - 1 && ", "}
                </span>
              ))}
            </div>
          </div>
        )}

        {/* 연찬 */}
        {record.hak.length > 0 && (
          <div className="flex items-start gap-2">
            <span className="shrink-0 rounded bg-blue-l px-1.5 py-0.5 text-[10px] font-semibold text-blue">연찬</span>
            <div className="flex flex-wrap gap-1">
              {record.hak.map((h, i) => (
                <span key={i} className="text-text">
                  {h.bookName} p.{h.startPage}~{h.endPage}{i < record.hak.length - 1 && ", "}
                </span>
              ))}
            </div>
          </div>
        )}

        {/* 결의 */}
        {record.resolution && (
          <div className="flex items-start gap-2">
            <span className="shrink-0 rounded bg-purple-l px-1.5 py-0.5 text-[10px] font-semibold text-purple">결의</span>
            <span className="text-text">{record.resolution}</span>
          </div>
        )}

        {/* 멤버 */}
        {record.members.length > 0 && (
          <div className="flex items-start gap-2">
            <span className="shrink-0 rounded bg-teal-l px-1.5 py-0.5 text-[10px] font-semibold text-teal">멤버</span>
            <div className="flex flex-wrap gap-1">
              {record.members.map((m, i) => (
                <span key={i} className="text-text">
                  {m.name}{m.branch ? ` ${m.branch}` : ""}({m.memo}){i < record.members.length - 1 && ", "}
                </span>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  )
}

// 연찬 섹션 - 책/어서 이름으로 그룹핑
function HakSection() {
  const [expandedBooks, setExpandedBooks] = useState<Record<string, boolean>>({})
  
  // 책 이름으로 그룹핑
  const groupedByBook: Record<string, { bookType: string; records: { date: string; startPage: string; endPage: string }[] }> = {}
  
  dummyRecords.forEach(record => {
    record.hak.forEach(h => {
      if (!groupedByBook[h.bookName]) {
        groupedByBook[h.bookName] = { bookType: h.bookType, records: [] }
      }
      groupedByBook[h.bookName].records.push({
        date: record.date,
        startPage: h.startPage,
        endPage: h.endPage,
      })
    })
  })
  
  // 각 책의 기록을 날짜순 정렬
  Object.keys(groupedByBook).forEach(bookName => {
    groupedByBook[bookName].records.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
  })
  
  const toggleBook = (bookName: string) => {
    setExpandedBooks(prev => ({ ...prev, [bookName]: !prev[bookName] }))
  }
  
  const formatDate = (dateStr: string) => {
    const date = new Date(dateStr)
    const days = ["일", "월", "화", "수", "목", "금", "토"]
    return `${date.getMonth() + 1}/${date.getDate()}(${days[date.getDay()]})`
  }
  
  const getTotalPages = (records: { startPage: string; endPage: string }[]) => {
    return records.reduce((sum, r) => {
      const start = parseInt(r.startPage) || 0
      const end = parseInt(r.endPage) || 0
      return sum + Math.max(0, end - start + 1)
    }, 0)
  }
  
  // 도서와 어서 분리
  const books = Object.entries(groupedByBook).filter(([_, data]) => data.bookType === "도서")
  const essays = Object.entries(groupedByBook).filter(([_, data]) => data.bookType === "어서" || data.bookType === "정기간행물")
  
  return (
    <div className="flex flex-col gap-3">
      {/* 도서 섹션 */}
      {books.length > 0 && (
        <div className="rounded-[var(--r)] border border-app-border bg-surface p-4">
          <h3 className="mb-3 text-[14px] font-bold text-text flex items-center gap-2">
            <span>&#128218;</span> 연찬 도서
            <span className="ml-auto rounded-full border border-blue/30 px-2 py-0.5 text-[11px] text-blue">{books.length}권</span>
          </h3>
          <div className="flex flex-col gap-2">
            {books.map(([bookName, data]) => {
              const isExpanded = expandedBooks[bookName]
              const totalPages = getTotalPages(data.records)
              
              return (
                <div key={bookName} className="rounded-lg border border-app-border overflow-hidden">
                  <button
                    onClick={() => toggleBook(bookName)}
                    className="flex w-full items-center justify-between p-3 hover:bg-blue-l/30 transition-colors"
                  >
                    <span className="text-[13px] font-semibold text-text">{bookName}</span>
                    <div className="flex items-center gap-2">
                      <span className="text-[11px] text-blue font-bold">{totalPages}p</span>
                      <ChevronDown className={cn("h-4 w-4 text-text3 transition-transform", isExpanded && "rotate-180")} />
                    </div>
                  </button>
                  
                  {isExpanded && (
                    <div className="border-t border-app-border bg-blue-l/20 px-3 py-2">
                      <div className="flex flex-col gap-1.5">
                        {data.records.map((record, idx) => (
                          <div key={idx} className="flex items-center justify-between text-[11px]">
                            <span className="text-text3">{formatDate(record.date)}</span>
                            <span className="text-blue">p.{record.startPage}~{record.endPage}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              )
            })}
          </div>
        </div>
      )}
      
      {/* 어서 섹션 */}
      {essays.length > 0 && (
        <div className="rounded-[var(--r)] border border-app-border bg-surface p-4">
          <h3 className="mb-3 text-[14px] font-bold text-text flex items-center gap-2">
            <span>&#128220;</span> 연찬 어서
            <span className="ml-auto rounded-full border border-amber-500/30 px-2 py-0.5 text-[11px] text-amber-600">{essays.length}편</span>
          </h3>
          <div className="flex flex-col gap-2">
            {essays.map(([bookName, data]) => {
              const isExpanded = expandedBooks[bookName]
              const totalPages = getTotalPages(data.records)
              
              return (
                <div key={bookName} className="rounded-lg border border-app-border overflow-hidden">
                  <button
                    onClick={() => toggleBook(bookName)}
                    className="flex w-full items-center justify-between p-3 hover:bg-amber-50 transition-colors"
                  >
                    <span className="text-[13px] font-semibold text-text">{bookName}</span>
                    <div className="flex items-center gap-2">
                      <span className="text-[11px] text-amber-600 font-bold">{totalPages}p</span>
                      <ChevronDown className={cn("h-4 w-4 text-text3 transition-transform", isExpanded && "rotate-180")} />
                    </div>
                  </button>
                  
                  {isExpanded && (
                    <div className="border-t border-app-border bg-amber-50/50 px-3 py-2">
                      <div className="flex flex-col gap-1.5">
                        {data.records.map((record, idx) => (
                          <div key={idx} className="flex items-center justify-between text-[11px]">
                            <span className="text-text3">{formatDate(record.date)}</span>
                            <span className="text-amber-600">p.{record.startPage}~{record.endPage}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              )
            })}
          </div>
        </div>
      )}
    </div>
  )
}

export function CollectionTab() {
  const [searchQuery, setSearchQuery] = useState("")
  const [activeFilter, setActiveFilter] = useState<FilterId>("all")
  const [reportText, setReportText] = useState(defaultReportText)
  const [showReportModal, setShowReportModal] = useState(false)
  const [copied, setCopied] = useState(false)

  const filteredRecords = dummyRecords
    .filter((record) => {
      if (!searchQuery) return true
      const query = searchQuery.toLowerCase()
      return (
        record.haeng.some((h) => h.name.toLowerCase().includes(query)) ||
        record.hak.some((h) => h.bookName.toLowerCase().includes(query)) ||
        record.resolution.toLowerCase().includes(query) ||
        record.members.some((m) => m.name.toLowerCase().includes(query) || m.memo.toLowerCase().includes(query))
      )
    })
    .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())

  const handleCopyReport = async () => {
    await navigator.clipboard.writeText(reportText)
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  const renderContent = () => {
    switch (activeFilter) {
      case "sin":
        return <SinSection />
      case "haeng":
        return <HaengSection />
      case "hak":
        return <HakSection />
      case "speech":
        return <SpeechSection />
      case "resolution":
        return <ResolutionSection />
      case "member":
        return <MemberSection />
      case "all":
      default:
        return filteredRecords.map((record, idx) => (
          <FullRecordCard key={idx} record={record} />
        ))
    }
  }

  return (
    <div className="flex flex-col pb-4">
      {/* 상단 액션바 */}
      <div className="sticky top-[44px] z-50 flex h-[48px] items-center justify-between border-b border-app-border bg-surface px-3">
        <button className="flex h-8 w-8 items-center justify-center rounded-lg border border-app-border">
          <ChevronLeft className="h-4 w-4 text-text2" />
        </button>
        <span className="text-[14px] font-bold text-text">2026년 4월</span>
        <div className="flex gap-1.5">
          <button className="flex h-8 w-8 items-center justify-center rounded-lg border border-app-border">
            <ChevronRight className="h-4 w-4 text-text2" />
          </button>
          <button 
            onClick={handleCopyReport}
            className={cn(
              "h-8 rounded-lg border px-3 text-[12px] font-bold transition-colors",
              copied 
                ? "border-green bg-green-l text-green" 
                : "border-purple bg-surface text-purple hover:bg-purple-l"
            )}
          >
            {copied ? "복사됨!" : "보고문구 복사"}
          </button>
          <button 
            onClick={() => setShowReportModal(true)}
            className="flex h-8 w-8 items-center justify-center rounded-lg border border-app-border text-text2 hover:border-green hover:text-green transition-colors"
          >
            <Edit2 className="h-4 w-4" />
          </button>
        </div>
      </div>

      {/* 검색창 */}
      <div className="px-3 py-2">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-text3" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="검색어를 입력하세요"
            className="h-[36px] w-full rounded-[var(--r-sm)] border-[1.5px] border-app-border bg-bg pl-9 pr-3 text-[13px] text-text placeholder:text-text3 focus:border-green focus:outline-none"
          />
        </div>
      </div>

      {/* 필터 필스 */}
      <div className="flex gap-2 overflow-x-auto px-3 pb-3">
        {filterPills.map((pill) => {
          const isActive = activeFilter === pill.id
          const styles = colorStyles[pill.color]
          return (
            <button
              key={pill.id}
              onClick={() => setActiveFilter(pill.id)}
              className={cn(
                "shrink-0 rounded-[var(--r-full)] px-3 py-1.5 text-[11px] font-semibold transition-colors",
                isActive ? styles.active : styles.inactive
              )}
            >
              {pill.label}
            </button>
          )
        })}
      </div>

      {/* 기록 목록 */}
      <div className="flex flex-col gap-3 px-3">
        {renderContent()}
      </div>

      {/* 보고문구 편집 모달 */}
      <ReportEditModal 
        isOpen={showReportModal} 
        onClose={() => setShowReportModal(false)} 
        reportText={reportText}
        onSave={setReportText}
      />
    </div>
  )
}
