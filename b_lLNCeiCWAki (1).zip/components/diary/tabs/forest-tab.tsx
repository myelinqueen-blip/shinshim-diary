"use client"

import { useState, useEffect } from "react"
import { cn } from "@/lib/utils"

// 격려 메시지 목록 (이모지 추가)
const defaultMessages = [
  "오늘도 정진하는 당신이 멋져요! 한 걸음 한 걸음이 큰 성장이 됩니다 &#128170;&#10024;",
  "꾸준함이 기적을 만들어요. 당신의 노력은 반드시 결실을 맺습니다 &#127793;&#127775;",
  "오늘의 작은 실천이 내일의 큰 변화로 이어집니다 &#127800;&#128156;",
  "포기하지 않는 당신을 응원해요! 매일 조금씩, 그게 비결이에요 &#128079;&#127995;&#10024;",
  "성장하는 당신의 모습이 아름다워요. 함께 전진합시다! &#127774;&#127807;",
]

// 창제표 설정
interface ChartConfig {
  word: string
  startDate: string
  endDate: string
  prayer: string
  goalMinutes: number
  completedMinutes: number
}

// 글자별 격자 패턴 정의 (7x5 격자 기반)
const LETTER_PATTERNS: Record<string, number[][]> = {
  "승": [
    [1,1,1,1,1,1,1],
    [0,0,0,1,0,0,0],
    [1,1,1,1,1,1,1],
    [1,0,0,1,0,0,1],
    [1,1,1,1,1,1,1],
  ],
  "리": [
    [1,1,1,0,1,1,1],
    [1,0,1,0,0,1,0],
    [1,1,1,0,0,1,0],
    [1,0,1,0,0,1,0],
    [1,0,1,0,1,1,1],
  ],
  "행": [
    [1,1,1,1,1,0,0],
    [0,1,0,1,0,0,0],
    [1,1,1,1,1,1,1],
    [0,1,0,1,0,1,0],
    [1,1,1,1,1,1,1],
  ],
  "복": [
    [1,1,1,1,1,1,1],
    [1,0,1,0,1,0,1],
    [1,1,1,1,1,1,1],
    [0,0,1,0,1,0,0],
    [0,1,1,1,1,1,0],
  ],
  "전": [
    [0,1,1,1,1,1,0],
    [0,0,0,1,0,0,0],
    [1,1,1,1,1,1,1],
    [0,0,0,1,0,0,0],
    [0,0,0,1,0,0,0],
  ],
  "진": [
    [1,1,1,1,1,1,1],
    [0,0,0,1,0,0,0],
    [0,1,1,1,1,1,0],
    [0,0,0,1,0,0,0],
    [0,1,1,1,1,1,0],
  ],
  "희": [
    [1,0,1,0,1,0,1],
    [0,1,0,1,0,1,0],
    [1,1,1,1,1,1,1],
    [0,1,0,1,0,1,0],
    [1,0,1,0,1,0,1],
  ],
  "망": [
    [1,1,1,1,1,1,1],
    [1,0,0,1,0,0,1],
    [1,1,1,1,1,1,1],
    [0,0,1,0,1,0,0],
    [0,1,1,1,1,1,0],
  ],
  "청": [
    [0,1,1,1,1,1,0],
    [0,1,0,0,0,1,0],
    [0,1,1,1,1,1,0],
    [1,0,0,1,0,0,1],
    [1,1,1,1,1,1,1],
  ],
  "년": [
    [0,0,1,1,1,0,0],
    [0,0,0,1,0,0,0],
    [1,1,1,1,1,1,1],
    [0,0,0,1,0,0,0],
    [0,0,1,1,1,0,0],
  ],
  "약": [
    [1,1,1,0,1,1,1],
    [1,0,0,0,0,0,1],
    [1,1,1,0,1,1,1],
    [0,0,1,0,1,0,0],
    [0,1,1,1,1,1,0],
  ],
  "동": [
    [0,1,1,1,1,1,0],
    [0,1,0,0,0,1,0],
    [0,1,1,1,1,1,0],
    [0,0,0,1,0,0,0],
    [1,1,1,1,1,1,1],
  ],
  "口": [
    [1,1,1,1,1,1,1],
    [1,0,0,0,0,0,1],
    [1,0,0,0,0,0,1],
    [1,0,0,0,0,0,1],
    [1,1,1,1,1,1,1],
  ],
  "月": [
    [1,1,1,1,1,1,1],
    [1,0,0,0,0,0,1],
    [1,1,1,1,1,1,1],
    [1,0,0,0,0,0,1],
    [1,1,1,1,1,1,1],
  ],
  "default": [
    [1,1,1,1,1,1,1],
    [1,0,0,0,0,0,1],
    [1,0,0,0,0,0,1],
    [1,0,0,0,0,0,1],
    [1,1,1,1,1,1,1],
  ],
}

// 더미 데이터
const dummyStats = {
  totalPrayerMinutes: 2340,
  activityCount: 156,
  meetingCount: 23,
  totalPages: 1284,
}

// 기본 창제표 설정
const defaultChartConfig: ChartConfig = {
  word: "승리",
  startDate: "2026-03-01",
  endDate: "2026-04-30",
  prayer: "세계 평화와 일체 중생의 행복을 기원합니다",
  goalMinutes: 3000,
  completedMinutes: 2340,
}

// 도서 목록 (페이지 수 포함)
const booksList = [
  { name: "21세기를 여는 대화", pages: 93 },
  { name: "법화경의 지혜", pages: 245 },
  { name: "새 인간혁명", pages: 312 },
  { name: "신 인간혁명", pages: 198 },
  { name: "인간혁명", pages: 156 },
  { name: "청춘대화", pages: 89 },
  { name: "행복의 꽃다발", pages: 124 },
  { name: "희망의 대화", pages: 67 },
]

// 어서 목록
const essaysList = [
  { name: "가을을 장식하는 환희의 대행진", pages: 12 },
  { name: "나와 함께 전진하는 동지에게", pages: 8 },
  { name: "대백련화의 청년들이여", pages: 15 },
  { name: "민중승리의 태양을 떠올려라", pages: 10 },
  { name: "봄을 여는 사자후", pages: 11 },
  { name: "비상하라 희망의 연대여", pages: 9 },
  { name: "승리의 미래를 향해", pages: 14 },
  { name: "위대한 사명의 궤도로", pages: 7 },
  { name: "인간혁명의 대서사시를", pages: 16 },
  { name: "전진 또 전진의 행진을", pages: 6 },
  { name: "창가의 대정신을 계승하라", pages: 13 },
  { name: "희망의 새벽을 여는 투사", pages: 11 },
]

// 숫자 포맷팅 (세자리 쉼표)
function formatNumber(num: number): string {
  return num.toLocaleString('ko-KR')
}

// 전광판 컴포넌트 (2배 느리게)
function MarqueeMessage({ 
  messages, 
  onEditClick 
}: { 
  messages: string[]
  onEditClick: () => void 
}) {
  const [currentIndex, setCurrentIndex] = useState(0)

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentIndex((prev) => (prev + 1) % messages.length)
    }, 24000)
    return () => clearInterval(interval)
  }, [messages.length])

  return (
    <div className="relative overflow-hidden bg-gradient-to-r from-green to-green2 px-4 py-3">
      <div className="flex items-center gap-2">
        <span className="shrink-0 text-[16px]">&#10024;</span>
        <div className="relative h-[20px] flex-1 overflow-hidden">
          <div
            key={currentIndex}
            className="absolute whitespace-nowrap text-[13px] font-semibold text-white animate-marquee"
            dangerouslySetInnerHTML={{ __html: messages[currentIndex] }}
          />
        </div>
        <button
          onClick={onEditClick}
          className="shrink-0 flex h-7 w-7 items-center justify-center rounded-full bg-white/20 text-[14px] hover:bg-white/30 transition-colors"
        >
          &#128172;
        </button>
      </div>
      <style jsx>{`
        @keyframes marquee {
          0% {
            transform: translateX(100%);
          }
          100% {
            transform: translateX(-150%);
          }
        }
        .animate-marquee {
          animation: marquee 24s linear infinite;
        }
      `}</style>
    </div>
  )
}

// 메시지 편집 모달
function MessageEditModal({
  isOpen,
  onClose,
  messages,
  onSave
}: {
  isOpen: boolean
  onClose: () => void
  messages: string[]
  onSave: (messages: string[]) => void
}) {
  const [editMessages, setEditMessages] = useState(messages)
  const [newMessage, setNewMessage] = useState("")

  if (!isOpen) return null

  const handleAdd = () => {
    if (newMessage.trim()) {
      setEditMessages([...editMessages, newMessage.trim()])
      setNewMessage("")
    }
  }

  const handleDelete = (index: number) => {
    setEditMessages(editMessages.filter((_, i) => i !== index))
  }

  const stripHtml = (html: string) => {
    return html.replace(/&#\d+;/g, (match) => {
      const code = parseInt(match.replace('&#', '').replace(';', ''))
      return String.fromCodePoint(code)
    })
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4">
      <div className="max-h-[80vh] w-full max-w-[360px] overflow-y-auto rounded-[var(--r)] bg-surface p-5">
        <h2 className="mb-4 text-center text-[16px] font-extrabold text-text">격려 메시지 편집</h2>
        
        <div className="mb-4 flex flex-col gap-2">
          {editMessages.map((msg, idx) => (
            <div key={idx} className="flex items-start gap-2">
              <div className="flex-1 rounded-lg bg-bg p-2 text-[12px] text-text">{stripHtml(msg)}</div>
              <button
                onClick={() => handleDelete(idx)}
                className="shrink-0 text-[12px] text-text3 hover:text-pink"
              >
                &#10005;
              </button>
            </div>
          ))}
        </div>

        <div className="mb-4 flex gap-2">
          <input
            type="text"
            value={newMessage}
            onChange={(e) => setNewMessage(e.target.value)}
            placeholder="새 메시지 입력..."
            className="flex-1 rounded-[var(--r-sm)] border-[1.5px] border-app-border bg-bg px-3 py-2 text-[13px] text-text placeholder:text-text3 focus:border-green focus:outline-none"
          />
          <button
            onClick={handleAdd}
            className="shrink-0 rounded-[var(--r-sm)] bg-green px-3 py-2 text-[12px] font-bold text-white"
          >
            추가
          </button>
        </div>

        <div className="flex gap-3">
          <button
            onClick={onClose}
            className="flex-1 rounded-[var(--r-sm)] border-[1.5px] border-app-border bg-surface py-2.5 text-[13px] font-bold text-text2"
          >
            취소
          </button>
          <button
            onClick={() => { onSave(editMessages); onClose() }}
            className="flex-1 rounded-[var(--r-sm)] bg-green py-2.5 text-[13px] font-bold text-white"
          >
            저장
          </button>
        </div>
      </div>
    </div>
  )
}

// 기간 헤더
function PeriodHeader({ config, onOpenModal }: { config: ChartConfig; onOpenModal: () => void }) {
  const formatDate = (dateStr: string) => {
    const date = new Date(dateStr)
    return `${date.getFullYear()}.${String(date.getMonth() + 1).padStart(2, '0')}.${String(date.getDate()).padStart(2, '0')}`
  }

  return (
    <div className="mx-3 mt-2 flex items-center justify-between px-1">
      <div className="flex items-center gap-2 text-[12px] text-text3">
        <span>&#128197;</span>
        <span>{formatDate(config.startDate)} ~ {formatDate(config.endDate)}</span>
      </div>
      <button
        onClick={onOpenModal}
        className="flex items-center gap-1 rounded-full border border-app-border bg-surface px-2 py-0.5 text-[10px] font-semibold text-text3 hover:border-green hover:text-green transition-colors"
      >
        <svg className="h-2.5 w-2.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z" />
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
        </svg>
        창제표
      </button>
    </div>
  )
}

// 통계 카드 (작은 크기)
function StatCard({ icon, value, label, bgColor }: { icon: React.ReactNode; value: string | number; label: string; bgColor: string }) {
  return (
    <div className={cn("flex flex-col items-center justify-center rounded-[10px] p-2", bgColor)}>
      <div className="text-[16px]">{icon}</div>
      <div className="mt-0.5 text-[14px] font-black text-text leading-tight">{value}</div>
      <div className="text-[9px] font-semibold text-text3">{label}</div>
    </div>
  )
}

// 창제표 모달 (단어 입력란 삭제)
function ChartModal({ isOpen, onClose, config, onSave }: { isOpen: boolean; onClose: () => void; config: ChartConfig; onSave: (config: ChartConfig) => void }) {
  const [startDate, setStartDate] = useState(config.startDate)
  const [endDate, setEndDate] = useState(config.endDate)
  const [prayer, setPrayer] = useState(config.prayer)
  const [goalHours, setGoalHours] = useState(Math.floor(config.goalMinutes / 60))

  useEffect(() => {
    if (isOpen) {
      setStartDate(config.startDate)
      setEndDate(config.endDate)
      setPrayer(config.prayer)
      setGoalHours(Math.floor(config.goalMinutes / 60))
    }
  }, [isOpen, config])

  if (!isOpen) return null

  const handleSave = () => {
    onSave({ ...config, startDate, endDate, prayer, goalMinutes: goalHours * 60 })
    onClose()
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4">
      <div className="max-h-[90vh] w-full max-w-[360px] overflow-y-auto rounded-[var(--r)] bg-surface p-5">
        <h2 className="mb-4 text-center text-[16px] font-extrabold text-text">창제표 설정</h2>
        
        <div className="mb-4 grid grid-cols-2 gap-3">
          <div>
            <label className="mb-1.5 block text-[12px] font-semibold text-text2">시작일</label>
            <input type="date" value={startDate} onChange={(e) => setStartDate(e.target.value)} className="w-full rounded-[var(--r-sm)] border-[1.5px] border-app-border bg-bg px-3 py-2 text-[13px] text-text focus:border-green focus:outline-none" />
          </div>
          <div>
            <label className="mb-1.5 block text-[12px] font-semibold text-text2">종료일</label>
            <input type="date" value={endDate} onChange={(e) => setEndDate(e.target.value)} className="w-full rounded-[var(--r-sm)] border-[1.5px] border-app-border bg-bg px-3 py-2 text-[13px] text-text focus:border-green focus:outline-none" />
          </div>
        </div>

        <div className="mb-4">
          <label className="mb-1.5 block text-[12px] font-semibold text-text2">목표 시간</label>
          <div className="flex items-center gap-2">
            <input type="number" value={goalHours} onChange={(e) => setGoalHours(Number(e.target.value))} min={1} max={500} className="w-24 rounded-[var(--r-sm)] border-[1.5px] border-app-border bg-bg px-3 py-2 text-center text-[14px] font-bold text-text focus:border-green focus:outline-none" />
            <span className="text-[13px] text-text2">시간</span>
            <span className="ml-auto text-[11px] text-text3">(30분당 1칸)</span>
          </div>
        </div>

        <div className="mb-5">
          <label className="mb-1.5 block text-[12px] font-semibold text-text2">기원문</label>
          <textarea value={prayer} onChange={(e) => setPrayer(e.target.value)} placeholder="기원하는 내용을 적어주세요" rows={3} className="w-full resize-none rounded-[var(--r-sm)] border-[1.5px] border-app-border bg-bg px-3 py-2.5 text-[13px] text-text placeholder:text-text3 focus:border-green focus:outline-none" />
        </div>

        <div className="flex gap-3">
          <button onClick={onClose} className="flex-1 rounded-[var(--r-sm)] border-[1.5px] border-app-border bg-surface py-2.5 text-[13px] font-bold text-text2">취소</button>
          <button onClick={handleSave} className="flex-1 rounded-[var(--r-sm)] bg-green py-2.5 text-[13px] font-bold text-white">저장</button>
        </div>
      </div>
    </div>
  )
}

// 시간에 따른 배경색 반환 (그라데이션으로 진해짐 - 아이콘 없음)
function getPlantBgColor(cellMinutes: number, minutesPerCell: number): string {
  const ratio = cellMinutes / minutesPerCell
  if (ratio < 0.2) return "bg-emerald-100"
  if (ratio < 0.4) return "bg-emerald-200"
  if (ratio < 0.6) return "bg-emerald-300"
  if (ratio < 0.8) return "bg-emerald-400"
  return "bg-emerald-500"
}

// 글자 모양 창제표 - 다양한 식물 아이콘
function WordShapeChart({ config }: { config: ChartConfig }) {
  const { word, completedMinutes, goalMinutes } = config
  
  // 각 글자별 패턴 가져오기
  const patterns = word.split("").map(char => LETTER_PATTERNS[char] || LETTER_PATTERNS["default"])
  
  // 전체 칸 수 계산
  const totalCells = patterns.reduce((sum, pattern) => 
    sum + pattern.reduce((rowSum, row) => rowSum + row.filter(c => c === 1).length, 0), 0
  )
  
  // 칸당 분 수
  const minutesPerCell = goalMinutes / totalCells
  let currentMinutes = completedMinutes
  let cellIndex = 0
  
  const progress = Math.min(100, Math.round((completedMinutes / goalMinutes) * 100))
  const completedHours = Math.floor(completedMinutes / 60)
  const completedMins = completedMinutes % 60
  const treeCount = Math.floor(completedMinutes / 30)

  return (
    <div className="rounded-[var(--r)] border border-app-border bg-surface p-4">
      <div className="mb-2 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <span className="text-[16px]">&#128591;&#127995;</span>
          <h3 className="text-[14px] font-extrabold text-text">나의 창제표</h3>
        </div>
        <span className="rounded-full bg-green-l px-2.5 py-1 text-[11px] font-bold text-green">{progress}% 달성</span>
      </div>

      <div className="mb-4 rounded-[8px] bg-gradient-to-r from-green-l to-blue-l p-3">
        <p className="text-center text-[11px] italic text-text2">{`"${config.prayer}"`}</p>
      </div>

      <div className="flex flex-wrap justify-center gap-1">
        {patterns.map((pattern, letterIdx) => (
          <div key={letterIdx} className="flex flex-col gap-[2px]">
            {pattern.map((row, rowIdx) => (
              <div key={rowIdx} className="flex gap-[2px]">
                {row.map((cell, colIdx) => {
                  if (cell === 0) return <div key={colIdx} className="h-[24px] w-[24px]" />
                  
                  const cellMins = Math.min(minutesPerCell, currentMinutes)
                  currentMinutes = Math.max(0, currentMinutes - minutesPerCell)
                  const isFilled = cellMins > 0
                  cellIndex++
                  
                  return (
                    <div 
                      key={colIdx} 
                      className={cn(
                        "h-[24px] w-[24px] rounded-[4px] transition-all duration-300",
                        isFilled 
                          ? getPlantBgColor(cellMins, minutesPerCell)
                          : "bg-gray-100"
                      )}
                    />
                  )
                })}
              </div>
            ))}
          </div>
        ))}
      </div>

      {/* 범례 */}
      <div className="mt-3 flex items-center justify-center gap-1 text-[9px] text-text3">
        <span>0분</span>
        <div className="flex gap-0.5">
          <div className="h-3 w-3 rounded-sm bg-gray-100" />
          <div className="h-3 w-3 rounded-sm bg-emerald-100" />
          <div className="h-3 w-3 rounded-sm bg-emerald-200" />
          <div className="h-3 w-3 rounded-sm bg-emerald-300" />
          <div className="h-3 w-3 rounded-sm bg-emerald-400" />
          <div className="h-3 w-3 rounded-sm bg-emerald-500" />
        </div>
        <span>180분+</span>
      </div>

      <p className="mt-2 text-center text-[12px] font-semibold text-text">
        총 <span className="text-green font-black">{treeCount}</span> 그루의 나무가 자랐어요!
      </p>

      <div className="mt-3 flex items-center justify-between text-[11px]">
        <span className="text-text3">완료: <span className="font-bold text-green">{completedHours}시간 {completedMins}분</span></span>
        <span className="text-text3">목표: <span className="font-bold text-text">{Math.floor(goalMinutes / 60)}시간</span></span>
      </div>

      <div className="mt-2 h-[6px] overflow-hidden rounded-full bg-app-border">
        <div className="h-full rounded-full bg-gradient-to-r from-green to-green2 transition-all duration-500" style={{ width: `${progress}%` }} />
      </div>
    </div>
  )
}

// 활동 횟수 시각화 - 초록색 새싹 아이콘
function ActivityVisualization({ count }: { count: number }) {
  // 그라데이션 단계 (진해지는 순서)
  const getColorByIndex = (idx: number, total: number) => {
    const ratio = idx / total
    if (ratio < 0.2) return "bg-green-100"
    if (ratio < 0.4) return "bg-green-200"
    if (ratio < 0.6) return "bg-green-300"
    if (ratio < 0.8) return "bg-green-400"
    return "bg-green-500"
  }

  return (
    <div className="rounded-[var(--r)] border border-app-border bg-surface p-4">
      <div className="mb-3 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <span className="text-[18px]">&#127793;</span>
          <h3 className="text-[14px] font-extrabold text-text">활동 횟수</h3>
        </div>
        <span className="text-[18px] font-black text-green">{formatNumber(count)}회</span>
      </div>
      
      {/* 새싹 그리드 */}
      <div className="flex flex-wrap justify-center gap-[6px]">
        {Array.from({ length: count }, (_, i) => (
          <div
            key={i}
            className={cn("flex h-[28px] w-[28px] items-center justify-center rounded-[5px]", getColorByIndex(i, count))}
          >
            <span className="text-[14px]">&#127793;</span>
          </div>
        ))}
      </div>
    </div>
  )
}

// 회합 참석 시각화 - 박수 아이콘
function MeetingVisualization({ count }: { count: number }) {
  // 그라데이션 단계 (진해지는 순서)
  const getColorByIndex = (idx: number, total: number) => {
    const ratio = idx / total
    if (ratio < 0.2) return "bg-amber-100"
    if (ratio < 0.4) return "bg-amber-200"
    if (ratio < 0.6) return "bg-amber-300"
    if (ratio < 0.8) return "bg-amber-400"
    return "bg-amber-500"
  }

  return (
    <div className="rounded-[var(--r)] border border-app-border bg-surface p-4">
      <div className="mb-3 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <span className="text-[18px]">&#128588;</span>
          <h3 className="text-[14px] font-extrabold text-text">회합 참석</h3>
        </div>
        <span className="text-[18px] font-black text-amber-600">{formatNumber(count)}회</span>
      </div>
      
      {/* 박수 그리드 */}
      <div className="flex flex-wrap justify-center gap-[6px]">
        {Array.from({ length: count }, (_, i) => (
          <div
            key={i}
            className={cn("flex h-[32px] w-[32px] items-center justify-center rounded-[5px]", getColorByIndex(i, count))}
          >
            <span className="text-[16px]">&#128588;</span>
          </div>
        ))}
      </div>
    </div>
  )
}

// 연찬 목록 (페이지 수 포함) - p로 표기
function StudyListWithPages({ title, icon, items, colorClass, bgClass, badgeColor, unit = "권" }: { title: string; icon: React.ReactNode; items: { name: string; pages: number }[]; colorClass: string; bgClass: string; badgeColor: string; unit?: string }) {
  const totalCount = items.length

  return (
    <div className="rounded-[var(--r)] border border-app-border bg-surface p-4">
      <div className="mb-3 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <span className="text-[16px]">{icon}</span>
          <h3 className="text-[14px] font-extrabold text-text">{title}</h3>
        </div>
        <span className={cn("rounded-full px-2.5 py-0.5 text-[12px] font-bold", badgeColor)}>{totalCount}{unit}</span>
      </div>
      
      <div className="flex flex-wrap gap-1.5">
        {items.map((item, idx) => (
          <span key={idx} className={cn("inline-flex rounded-full px-3 py-1.5 text-[11px] font-medium", bgClass, colorClass)}>
            {item.name}
          </span>
        ))}
      </div>
    </div>
  )
}

// 숲 배경 푸터 - 자연스러운 그라데이션
function ForestFooter() {
  return (
    <div className="relative -mx-3 mt-6 h-16 overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-t from-green-100/50 via-green-50/30 to-transparent" />
    </div>
  )
}

export function ForestTab() {
  const [chartConfig, setChartConfig] = useState<ChartConfig>(defaultChartConfig)
  const [showChartModal, setShowChartModal] = useState(false)
  const [messages, setMessages] = useState(defaultMessages)
  const [showMessageModal, setShowMessageModal] = useState(false)

  const hours = Math.floor(dummyStats.totalPrayerMinutes / 60)

  return (
    <div className="flex flex-col pb-4">
      {/* 전광판 */}
      <MarqueeMessage messages={messages} onEditClick={() => setShowMessageModal(true)} />

      {/* 기간 표시 */}
      <PeriodHeader config={chartConfig} onOpenModal={() => setShowChartModal(true)} />

      {/* 통계 카드 그리드 */}
      <div className="mx-3 mt-3 grid grid-cols-4 gap-1.5">
        <StatCard icon="&#128591;&#127995;" value={`${hours}h`} label="창제" bgColor="bg-gradient-to-br from-sky-100 to-blue-200" />
        <StatCard icon="&#127793;" value={formatNumber(dummyStats.activityCount)} label="격려" bgColor="bg-green-l" />
        <StatCard icon="&#127793;" value={formatNumber(dummyStats.meetingCount)} label="회합" bgColor="bg-green-l" />
        <StatCard icon="&#128214;" value={`${formatNumber(dummyStats.totalPages)}p`} label="연찬" bgColor="bg-cyan-100" />
      </div>

      {/* 나의 창제표 */}
      <div className="mx-3 mt-4">
        <WordShapeChart config={chartConfig} />
      </div>

      {/* 활동 횟수 */}
      <div className="mx-3 mt-3">
        <ActivityVisualization count={dummyStats.activityCount} />
      </div>

      {/* 회합 참석 */}
      <div className="mx-3 mt-3">
        <MeetingVisualization count={dummyStats.meetingCount} />
      </div>

      {/* 연찬 도서 */}
      <div className="mx-3 mt-3">
        <StudyListWithPages 
          title="연찬 도서" 
          icon="&#128218;" 
          items={booksList} 
          colorClass="text-cyan-700" 
          bgClass="bg-cyan-50" 
          badgeColor="border border-cyan-200 text-cyan-600"
          unit="권"
        />
      </div>

      {/* 연찬 어서 */}
      <div className="mx-3 mt-3">
        <StudyListWithPages 
          title="연찬 어서" 
          icon="&#128220;" 
          items={essaysList} 
          colorClass="text-yellow-700" 
          bgClass="bg-yellow-50" 
          badgeColor="border border-yellow-300 text-yellow-600"
          unit="편"
        />
      </div>

      {/* 숲 배경 푸터 */}
      <ForestFooter />

      {/* 모달들 */}
      <ChartModal isOpen={showChartModal} onClose={() => setShowChartModal(false)} config={chartConfig} onSave={setChartConfig} />
      <MessageEditModal isOpen={showMessageModal} onClose={() => setShowMessageModal(false)} messages={messages} onSave={setMessages} />
    </div>
  )
}
