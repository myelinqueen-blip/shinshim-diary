"use client"

import { useState, useEffect } from "react"
import { DateNavigation } from "../date-navigation"
import { SinSection } from "../sections/sin-section"
import { HaengSection } from "../sections/haeng-section"
import { HakSection } from "../sections/hak-section"
import { SpeechSection, ResolutionSection } from "../sections/speech-section"
import { MemberSection } from "../sections/member-section"
import { ActivitySection } from "../sections/activity-section"

interface HaengItem {
  id: string
  name: string
  type: string
  category: string
  customType?: string
}

interface HakItem {
  id: string
  bookType: string
  bookName: string
  startPage: string
  endPage: string
}

interface MemberItem {
  id: string
  name: string
  memo: string
}

interface ActivityItem {
  id: string
  date: string
  name: string
  category: string
  type: string
  customType?: string
  companion: string
}

export function RecordTab() {
  const [mounted, setMounted] = useState(false)
  const [date, setDate] = useState<Date | null>(null)
  const [sinMinutes, setSinMinutes] = useState("")
  const [haengItems, setHaengItems] = useState<HaengItem[]>([
    { id: "1", name: "", type: "", category: "", customType: "" },
  ])
  const [hakItems, setHakItems] = useState<HakItem[]>([
    { id: "1", bookType: "도서", bookName: "", startPage: "", endPage: "" },
  ])
  const [speech, setSpeech] = useState("")
  const [resolution, setResolution] = useState("")
  const [memberItems, setMemberItems] = useState<MemberItem[]>([
    { id: "1", name: "", memo: "" },
  ])
  const [activityItems, setActivityItems] = useState<ActivityItem[]>([
    { id: "1", date: "", name: "", category: "", type: "", customType: "", companion: "" },
  ])

  useEffect(() => {
    setDate(new Date())
    setMounted(true)
  }, [])

  const handleToday = () => {
    setDate(new Date())
  }

  const handleSave = () => {
    console.log("저장됨", {
      date,
      sinMinutes,
      haengItems,
      hakItems,
      speech,
      resolution,
      memberItems,
      activityItems,
    })
  }

  if (!mounted || !date) {
    return (
      <div className="relative pb-24">
        <div className="sticky top-[44px] z-50 flex h-[54px] items-center gap-2 border-b border-app-border bg-surface px-3">
          <div className="h-[40px] w-[40px] animate-pulse rounded-[10px] bg-gray-100" />
          <div className="flex flex-1 max-w-[150px] flex-col items-center justify-center gap-1">
            <div className="h-3 w-10 animate-pulse rounded bg-gray-100" />
            <div className="h-5 w-24 animate-pulse rounded bg-gray-100" />
          </div>
          <div className="h-[40px] w-[40px] animate-pulse rounded-[10px] bg-gray-100" />
          <div className="ml-auto h-[36px] w-14 animate-pulse rounded-[var(--r-sm)] bg-gray-100" />
        </div>
      </div>
    )
  }

  return (
    <div className="relative pb-24">
      <DateNavigation
        date={date}
        onDateChange={setDate}
        onToday={handleToday}
      />

      <div className="flex flex-col gap-2 py-2">
        <SinSection
          minutes={sinMinutes}
          onMinutesChange={setSinMinutes}
          goal={90}
        />

        <HaengSection
          items={haengItems}
          onItemsChange={setHaengItems}
          goal={3}
        />

        <HakSection
          items={hakItems}
          onItemsChange={setHakItems}
          goal={30}
        />

        <SpeechSection
          value={speech}
          onChange={setSpeech}
        />

        <ResolutionSection
          value={resolution}
          onChange={setResolution}
        />

        <MemberSection
          items={memberItems}
          onItemsChange={setMemberItems}
        />

        <ActivitySection
          items={activityItems}
          onItemsChange={setActivityItems}
        />
      </div>

      {/* 저장 플로팅 버튼 */}
      <button
        onClick={handleSave}
        className="fixed bottom-[18px] left-1/2 -translate-x-1/2 rounded-[24px] bg-green px-10 py-[13px] text-[14px] font-extrabold text-white shadow-lg"
      >
        저장 &#127807;
      </button>
    </div>
  )
}
