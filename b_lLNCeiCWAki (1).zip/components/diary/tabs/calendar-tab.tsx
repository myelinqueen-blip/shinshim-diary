"use client"

import { useState, useMemo } from "react"
import { ChevronLeft, ChevronRight } from "lucide-react"
import { cn } from "@/lib/utils"

const dayNames = ["일", "월", "화", "수", "목", "금", "토"]

// 더미 기록 데이터
const dummyRecords: Record<string, { sin: number; haeng: number; hak: number }> = {
  "2026-4-1": { sin: 60, haeng: 2, hak: 15 },
  "2026-4-2": { sin: 90, haeng: 3, hak: 20 },
  "2026-4-3": { sin: 45, haeng: 1, hak: 10 },
  "2026-4-4": { sin: 120, haeng: 4, hak: 25 },
  "2026-4-5": { sin: 30, haeng: 0, hak: 5 },
}

export function CalendarTab() {
  const [currentDate, setCurrentDate] = useState(new Date())
  const [selectedDate, setSelectedDate] = useState<Date | null>(null)

  const year = currentDate.getFullYear()
  const month = currentDate.getMonth()

  const calendarDays = useMemo(() => {
    const firstDay = new Date(year, month, 1)
    const lastDay = new Date(year, month + 1, 0)
    const daysInMonth = lastDay.getDate()
    const startDayOfWeek = firstDay.getDay()

    const days: (number | null)[] = []
    
    // 이전 달의 빈 칸
    for (let i = 0; i < startDayOfWeek; i++) {
      days.push(null)
    }
    
    // 현재 달의 날짜
    for (let i = 1; i <= daysInMonth; i++) {
      days.push(i)
    }

    return days
  }, [year, month])

  const handlePrevMonth = () => {
    setCurrentDate(new Date(year, month - 1, 1))
  }

  const handleNextMonth = () => {
    setCurrentDate(new Date(year, month + 1, 1))
  }

  const getRecordForDay = (day: number) => {
    const key = `${year}-${month + 1}-${day}`
    return dummyRecords[key]
  }

  const isToday = (day: number) => {
    const today = new Date()
    return (
      day === today.getDate() &&
      month === today.getMonth() &&
      year === today.getFullYear()
    )
  }

  const isSelected = (day: number) => {
    if (!selectedDate) return false
    return (
      day === selectedDate.getDate() &&
      month === selectedDate.getMonth() &&
      year === selectedDate.getFullYear()
    )
  }

  return (
    <div className="flex flex-col">
      {/* 월 네비게이션 */}
      <div className="sticky top-[44px] z-50 flex h-[48px] items-center justify-between border-b border-app-border bg-surface px-4">
        <button
          onClick={handlePrevMonth}
          className="flex h-8 w-8 items-center justify-center rounded-lg border border-app-border"
        >
          <ChevronLeft className="h-4 w-4 text-text2" />
        </button>
        <span className="text-[16px] font-bold text-text">
          {year}년 {month + 1}월
        </span>
        <button
          onClick={handleNextMonth}
          className="flex h-8 w-8 items-center justify-center rounded-lg border border-app-border"
        >
          <ChevronRight className="h-4 w-4 text-text2" />
        </button>
      </div>

      {/* 요일 헤더 */}
      <div className="grid grid-cols-7 border-b border-app-border bg-surface">
        {dayNames.map((day, i) => (
          <div
            key={day}
            className={cn(
              "py-2 text-center text-[11px] font-semibold",
              i === 0 ? "text-pink" : i === 6 ? "text-blue" : "text-text3"
            )}
          >
            {day}
          </div>
        ))}
      </div>

      {/* 캘린더 그리드 */}
      <div className="grid grid-cols-7 gap-px bg-app-border">
        {calendarDays.map((day, i) => {
          if (day === null) {
            return <div key={i} className="aspect-square bg-surface" />
          }

          const record = getRecordForDay(day)
          const hasRecord = !!record
          const dayOfWeek = (i % 7)

          return (
            <button
              key={i}
              onClick={() => setSelectedDate(new Date(year, month, day))}
              className={cn(
                "relative flex aspect-square flex-col items-center bg-surface p-1 transition-colors",
                isSelected(day) && "bg-green-l",
                isToday(day) && "ring-2 ring-inset ring-green"
              )}
            >
              <span
                className={cn(
                  "text-[12px] font-semibold",
                  dayOfWeek === 0 ? "text-pink" : dayOfWeek === 6 ? "text-blue" : "text-text",
                  isToday(day) && "text-green"
                )}
              >
                {day}
              </span>
              
              {/* 기록 도트 */}
              {hasRecord && (
                <div className="mt-0.5 flex gap-0.5">
                  {record.sin > 0 && (
                    <div className="h-1.5 w-1.5 rounded-full bg-green" />
                  )}
                  {record.haeng > 0 && (
                    <div className="h-1.5 w-1.5 rounded-full bg-pink" />
                  )}
                  {record.hak > 0 && (
                    <div className="h-1.5 w-1.5 rounded-full bg-blue" />
                  )}
                </div>
              )}
            </button>
          )
        })}
      </div>

      {/* 선택된 날짜의 기록 요약 */}
      {selectedDate && (
        <div className="mx-3 mt-3 rounded-[var(--r)] border border-app-border bg-surface p-4">
          <h3 className="mb-3 text-[14px] font-extrabold text-text">
            {selectedDate.getMonth() + 1}월 {selectedDate.getDate()}일 기록
          </h3>
          
          {(() => {
            const record = getRecordForDay(selectedDate.getDate())
            if (!record) {
              return (
                <p className="text-center text-[13px] text-text3">
                  기록이 없습니다
                </p>
              )
            }
            return (
              <div className="flex justify-around">
                <div className="text-center">
                  <div className="text-[10px] font-semibold text-text3">신·창제</div>
                  <div className="text-[18px] font-black text-green">
                    {Math.floor(record.sin / 60)}h {record.sin % 60}m
                  </div>
                </div>
                <div className="text-center">
                  <div className="text-[10px] font-semibold text-text3">행·활동</div>
                  <div className="text-[18px] font-black text-pink">{record.haeng}명</div>
                </div>
                <div className="text-center">
                  <div className="text-[10px] font-semibold text-text3">학·연찬</div>
                  <div className="text-[18px] font-black text-blue">{record.hak}p</div>
                </div>
              </div>
            )
          })()}
          
          <button className="mt-3 w-full rounded-[var(--r-sm)] border border-app-border py-2 text-[12px] font-semibold text-text2">
            기록보기
          </button>
        </div>
      )}

      {/* 범례 */}
      <div className="mx-3 mt-3 mb-4 flex justify-center gap-4">
        <div className="flex items-center gap-1.5">
          <div className="h-2 w-2 rounded-full bg-green" />
          <span className="text-[10px] text-text3">신·창제</span>
        </div>
        <div className="flex items-center gap-1.5">
          <div className="h-2 w-2 rounded-full bg-pink" />
          <span className="text-[10px] text-text3">행·활동</span>
        </div>
        <div className="flex items-center gap-1.5">
          <div className="h-2 w-2 rounded-full bg-blue" />
          <span className="text-[10px] text-text3">학·연찬</span>
        </div>
      </div>
    </div>
  )
}
