"use client"

import { cn } from "@/lib/utils"

const tabs = [
  { id: "record", label: "기록" },
  { id: "collection", label: "모음" },
  { id: "calendar", label: "캘린더" },
  { id: "forest", label: "복운의 숲" },
] as const

export type TabId = (typeof tabs)[number]["id"]

interface TabBarProps {
  activeTab: TabId
  onTabChange: (tab: TabId) => void
}

export function TabBar({ activeTab, onTabChange }: TabBarProps) {
  return (
    <nav className="sticky top-0 z-100 flex h-[44px] w-full items-center border-b-[1.5px] border-app-border bg-surface">
      {tabs.map((tab) => (
        <button
          key={tab.id}
          onClick={() => onTabChange(tab.id)}
          className={cn(
            "flex-1 h-full text-[12px] font-semibold transition-colors",
            activeTab === tab.id
              ? "text-green border-b-[2.5px] border-green font-extrabold"
              : "text-text3"
          )}
        >
          {tab.label}
        </button>
      ))}
    </nav>
  )
}
