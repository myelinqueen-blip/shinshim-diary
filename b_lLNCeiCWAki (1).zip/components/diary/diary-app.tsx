"use client"

import { useState } from "react"
import { TabBar, type TabId } from "./tab-bar"
import { RecordTab } from "./tabs/record-tab"
import { CollectionTab } from "./tabs/collection-tab"
import { CalendarTab } from "./tabs/calendar-tab"
import { ForestTab } from "./tabs/forest-tab"

export function DiaryApp() {
  const [activeTab, setActiveTab] = useState<TabId>("record")

  return (
    <div className="mx-auto min-h-screen max-w-[390px] bg-bg">
      <TabBar activeTab={activeTab} onTabChange={setActiveTab} />
      
      <main className="flex-1">
        {activeTab === "record" && <RecordTab />}
        {activeTab === "collection" && <CollectionTab />}
        {activeTab === "calendar" && <CalendarTab />}
        {activeTab === "forest" && <ForestTab />}
      </main>
    </div>
  )
}
