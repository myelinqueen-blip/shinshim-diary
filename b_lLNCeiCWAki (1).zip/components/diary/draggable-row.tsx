"use client"

import { GripVertical } from "lucide-react"

interface DraggableRowProps {
  children: React.ReactNode
  onDelete?: () => void
  showHandle?: boolean
}

export function DraggableRow({ children, onDelete, showHandle = true }: DraggableRowProps) {
  return (
    <div className="flex items-center gap-1.5">
      {/* 드래그 핸들 */}
      {showHandle && (
        <div className="flex h-[34px] w-[16px] cursor-grab items-center justify-center text-app-border">
          <GripVertical className="h-4 w-4" />
        </div>
      )}
      
      {/* 내용 */}
      <div className="flex flex-1 items-center gap-1.5">{children}</div>
      
      {/* 삭제 버튼 */}
      {onDelete && (
        <button
          onClick={onDelete}
          className="flex h-[14px] w-[14px] items-center justify-center text-[11px] text-[#C8D4DC]"
        >
          ✕
        </button>
      )}
    </div>
  )
}

// +추가 버튼 컴포넌트
export function AddButton({ onClick, label = "추가" }: { onClick: () => void; label?: string }) {
  return (
    <button
      onClick={onClick}
      className="ml-[21px] text-[11px] font-semibold text-green"
    >
      + {label}
    </button>
  )
}
