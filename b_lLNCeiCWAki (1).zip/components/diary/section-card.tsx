"use client"

import { cn } from "@/lib/utils"

type ColorType = "green" | "pink" | "blue" | "purple" | "teal"

interface SectionCardProps {
  title: string
  subtitle?: string
  color?: ColorType
  headerRight?: React.ReactNode
  children: React.ReactNode
}

const colorMap: Record<ColorType, string> = {
  green: "bg-green",
  pink: "bg-pink",
  blue: "bg-blue",
  purple: "bg-purple",
  teal: "bg-teal",
}

export function SectionCard({
  title,
  subtitle,
  color = "green",
  headerRight,
  children,
}: SectionCardProps) {
  return (
    <div className="mx-3 mt-2 overflow-hidden rounded-[var(--r)] border border-app-border bg-surface">
      {/* 헤더 */}
      <div className="flex items-center gap-2 border-b border-app-border px-3 py-2.5">
        {/* 색상 바 */}
        <div className={cn("h-[28px] w-[4px] rounded-[4px]", colorMap[color])} />
        
        {/* 타이틀 */}
        <h3 className="text-[14px] font-extrabold text-text">{title}</h3>
        
        {/* 서브타이틀 */}
        {subtitle && (
          <span className="text-[11px] font-semibold text-text3">{subtitle}</span>
        )}
        
        {/* 우측 컨텐츠 */}
        {headerRight && <div className="ml-auto">{headerRight}</div>}
      </div>

      {/* 바디 */}
      <div className="p-3">{children}</div>
    </div>
  )
}
