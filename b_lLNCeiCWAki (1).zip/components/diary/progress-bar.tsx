"use client"

import { cn } from "@/lib/utils"

type ColorType = "green" | "pink" | "blue"

interface ProgressBarProps {
  value: number
  max: number
  color?: ColorType
  showLabels?: boolean
  leftLabel?: string
  rightLabel?: string
}

const fillColorMap: Record<ColorType, string> = {
  green: "bg-green",
  pink: "bg-pink",
  blue: "bg-blue",
}

export function ProgressBar({
  value,
  max,
  color = "green",
  showLabels = true,
  leftLabel,
  rightLabel,
}: ProgressBarProps) {
  const percentage = max > 0 ? Math.min((value / max) * 100, 100) : 0

  return (
    <div className="w-full">
      <div className="h-[5px] w-full overflow-hidden rounded-[6px] bg-app-border">
        <div
          className={cn("h-full rounded-[6px] transition-all duration-300", fillColorMap[color])}
          style={{ width: `${percentage}%` }}
        />
      </div>
      {showLabels && (
        <div className="mt-1 flex justify-between text-[11px] text-text3">
          <span>{leftLabel || `${value}`}</span>
          <span>{rightLabel || `${Math.round(percentage)}%`}</span>
        </div>
      )}
    </div>
  )
}
